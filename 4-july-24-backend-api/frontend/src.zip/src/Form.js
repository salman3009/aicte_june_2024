import React, { useState } from 'react'

const Form = () => {
    const [formData, setFormData] = useState({ firstName: '', lastName: '', email: '', gender: '', age: '', vehicle1: '', vehicle2: '', vehicle3: '' })
    const [errors, setErrors] = useState({ firstName: '', lastName: '', email: '', gender: '', age: '', vehicle: '' })

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value })
        formValidation()
    }

    const formValidation = () => {
        let newErrors = {};

        if ((formData.firstName).length < 8) {
            newErrors.firstName = "Your First Name should have more then 8 characters";
        }
        else if ((formData.lastName).length < 2) {
            newErrors.lastName = "Your Last Name should have more then 2 characters";
        }
        else if (!emailRegex.test(formData.email)) {
            newErrors.email = "Please Enter a Proper Email";
        }
        else if ((formData.gender).trim() === '') {
            newErrors.gender = "Please Select the Gender Field";
        }

        else if ((formData.vehicle1).trim() === '' && (formData.vehicle2).trim() === '' && (formData.vehicle3).trim() === '') {
            newErrors.vehicle = "Please Select Vehicle Field";
        }
        else if ((formData.age).trim() === '') {
            newErrors.age = "Please Select Age Field";
        }
        setErrors(newErrors);
    }

    return (
        <div>
            <form onSubmit={(e) => { e.preventDefault() }}>
                <div className='row pt-5'>
                    <div className='col-md-4'>
                        <div className="mb-3 form-check">
                            <label htmlFor='firstName'>{`First   Name`}<span className="text-danger">*</span></label>
                            <input type="text" className="form-control border border-dark border-1" id="firstName" name="firstName" value={formData.firstName} onChange={handleChange} required />
                        </div>
                        {
                            errors.firstName && (
                                <p className='text-danger'>{errors.firstName}</p>
                            )
                        }
                    </div>
                    <div className='col-md-4'>
                        <div className="mb-3 form-check">
                            <label htmlFor='lastName'>Last Name <span className="text-danger">*</span></label>
                            <input type="text" className="form-control border border-dark border-1" id="lastName" name="lastName" value={formData.lastName} onChange={handleChange} required />
                        </div>
                        {
                            errors.lastName && (
                                <p className='text-danger'>{errors.lastName}</p>
                            )
                        }
                    </div>
                    <div className='col-md-4'>
                        <div className="mb-3 form-check">
                            <label htmlFor='email'>Email <span className="text-danger">*</span></label>
                            <input type="text" className="form-control border border-dark border-1" id="email" name="email" value={formData.email} onChange={handleChange} required />
                        </div>
                        {
                            errors.email && (
                                <p className='text-danger'>{errors.email}</p>
                            )
                        }
                    </div>
                </div>
                <div className='row pt-5'>
                    <div className='col-md-4'>
                        <div className="mb-3 form-check">
                            <label htmlFor="gender" className="form-label">Choose Your Gender:</label>
                            <select className="form-select form-select-lg" id="gender" name="gender" value={formData.gender} onChange={handleChange} >
                                <option value="">Select your gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="others">Others</option>
                            </select>
                            {
                                errors.gender && (
                                    <p className='text-danger'>{errors.gender}</p>
                                )
                            }
                        </div>
                    </div>
                    <div className='col-md-4'>
                        <div className="mb-3 form-check">
                            <input type="checkbox" className="form-check-input" id="vehicle1" name="vehicle1" value={formData.email} onChange={handleChange} />
                            <label htmlFor="vehicle1" className="form-check-label">I have a bike</label><br />
                            <input type="checkbox" className="form-check-input" id="vehicle2" name="vehicle2" value={formData.email} onChange={handleChange} />
                            <label htmlFor="vehicle2" className="form-check-label">I have a car</label><br />
                            <input type="checkbox" className="form-check-input" id="vehicle3" name="vehicle3" value={formData.email} onChange={handleChange} />
                            <label htmlFor="vehicle3" className="form-check-label">I have a boat</label>
                        </div>
                        {
                                errors.vehicle && (
                                    <p className='text-danger'>{errors.vehicle}</p>
                                )
                            }
                    </div>
                    <div className='col-md-4'>
                        <div className="mb-3 form-check">
                            <input type="radio" className="form-check-input" id="age1" name="age" value={formData.email} onChange={handleChange} />
                            <label htmlFor="age1" className="form-check-label">0 - 30</label><br />
                            <input type="radio" className="form-check-input" id="age2" name="age" value={formData.email} onChange={handleChange} />
                            <label htmlFor="age2" className="form-check-label">31 - 60</label><br />
                            <input type="radio" className="form-check-input" id="age3" name="age" value={formData.email} onChange={handleChange} />
                            <label htmlFor="age3" className="form-check-label">61 - 99</label>
                        </div>
                        {
                            errors.age && (
                                <p className='text-danger'>{errors.age}</p>
                            )
                        }
                    </div>
                </div>
                <div className='row pt-5'>
                    <div className='col-md-4'>
                    </div>
                    <div className='col-md-4'>
                        <div className="d-flex justify-content-center">
                            <input type="submit" className="btn btn-primary" onClick={formValidation} />
                        </div>
                    </div>
                </div>

            </form >
        </div >
    )
}

export default Form