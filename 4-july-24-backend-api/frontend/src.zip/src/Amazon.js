import Product from './Product';
import './Product.css';

const Amazon = () => {
    return (<div className="listpage">
                <Product 
                        image={require(`./assets/Wearables._CB574550011_.png`)} topic="Noise Buds N1" 
                        list1="40 hrs &gt; of Playtime" list2="40 ms Ultra Low Latency" 
                        price="3,499" discountPrice="1,099"/>
                <Product 
                        image={require(`./assets/Tablets._CB574550011_.png`)} topic="Noise Plus 3 Max" 
                        list1="2.0 Display" list2="Functional Crown" 
                        price="6,999" discountPrice="1,399"/>
                <Product 
                        image={require(`./assets/SECURITY-CAMERA._CB574546476_.png`)} topic="Logitech G300s" 
                        list1="9 Programmable Controls" list2="2500 DPI" 
                        price="2,295" discountPrice="999"/>
                <Product 
                        image={require(`./assets/HF_PHASE_978X900._SS900_QL85_.jpg`)} topic="Tygot Ring light tripod" 
                        list1="USB-Powered" list2="Color Adjustment" 
                        price="1,999" discountPrice="799"/>
                <Product 
                        image={require(`./assets/Headphones._CB574550011_.png`)} topic="boAt Airdopes 91" 
                        list1="45 hrs Playtime" list2="50 ms Low Latency" 
                        price="4,900" discountPrice="799"/>
                <Product 
                        image={require(`./assets/moonwatch-978x900_SL._SS900_QL85_.jpg`)} topic="Visionary Ultra" 
                        list1="fStainless steel Luxury" list2="1.98 AMOLED" 
                        price="2900" discountPrice="2400"/>
                <Product 
                        image={require(`./assets/HEADPHONE._CB574546476_.png`)} topic="CP plus Ezylite 3MP" 
                        list1="Al-based human detection" list2="Night vision" 
                        price="2,300" discountPrice="1,299"/>
                <Product 
                        image={require(`./assets/Maono_MIC_Spotlight._SS900_QL85_.jpg`)} topic="VW Car Dash Camera" 
                        list1="FHD footage" list2="low light performance" 
                        price="6,999" discountPrice="1,799"/>
            </div>
    )
}

export default Amazon