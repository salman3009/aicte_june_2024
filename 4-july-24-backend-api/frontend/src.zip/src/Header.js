import React from 'react'
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'

const Header = () => {
  const navigate = useNavigate();

  const handleSubmit = () => {
    localStorage.setItem('isLoggedIn', false);
    navigate("/")
  }
  let isLoggedIn = JSON.parse(localStorage.getItem('isLoggedIn'))
  console.log(typeof isLoggedIn); // Output: "string"
  return (
    <div className='row' style={{ "background": "#e1d9d9" }}>
      <div className='col-md-4'>
        <Link style={{ "fontSize": "20px", "paddingLeft": "30px" }} to="/">Spotify</Link>
      </div>
      <div className='col-md-6' style={{ "marginLeft": "90%" }}>
        <div>
          {(isLoggedIn===true) ? (
            <li><img src="/static/media/1._SS300_QL85_FMpng_.993e58e00493b801f519.png" alt="google" style={{ "width": "40px", "height": "35px" }} />
              <Link to="/login" class="nav-link" onClick={handleSubmit}>Logout</Link></li>
          ) : (
            <div className="col-md-2">
              <Link style={{ "fontSize": "16px" }} to="/login">Login</Link>
              <Link className="textLg" to="/register" style={{ "fontSize": "16px", "paddingLeft": "10px" }}>Register</Link>
            </div>
          )}
        </div>
      </div>

    </div>
  )
}

export default Header