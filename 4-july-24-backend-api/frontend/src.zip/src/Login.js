import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const Login = () => {

  const [formData, setFormData] = useState({ email: '', password: '' })
  const [errors, setErrors] = useState({ email: '', password: '' })
  const navigate = useNavigate();

  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value })
  }

  const handleSubmit = () => {
    if (formValidation()) {
      localStorage.setItem('isLoggedIn', true);
      navigate("/")
    }
  }

  const formValidation = () => {
    let newErrors = {};
    let validation = true

    if (!emailRegex.test(formData.email)) {
      newErrors.email = "Please Enter a Proper Email";
      validation = false
    }
    else if ((formData.password).trim() === '') {
      newErrors.password = "Password should not be Empty";
      validation = false
    }

    setErrors(newErrors);
    return validation;
  }

  return (
    <form onSubmit={(e) => { e.preventDefault() }}>
      <div className='row pt-5'>
        <div className='col-md-4'></div><div className='col-md-4'>
          <div className="mb-3 form-check">
            <label htmlFor="exampleInputEmail1">Email address</label>
            <input type="email" className="form-control" aria-describedby="emailHelp" placeholder="Enter email" name="email" id="email" value={formData.email} onChange={handleChange} required />
            <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
          </div>
          {
            errors.email && (
              <p className='text-danger'>{errors.email}</p>
            )
          }

          <div className="mb-3 form-check">
            <label htmlFor="exampleInputPassword1">Password</label>
            <input type="password" className="form-control" name="password" id="password" placeholder="Password" value={formData.password} onChange={handleChange} required />
          </div>
          {
            errors.password && (
              <p className='text-danger'>{errors.password}</p>
            )
          }

          <button type="submit" className="btn btn-primary" onClick={handleSubmit}>Submit</button>
        </div>
      </div>
    </form>
  )
}

export default Login