import React from 'react'
import googleImage from './assets/google.webp'

const ImageWithText = () => {
  return (
    <div>
        <img className="ImgDimension" src ={googleImage} alt="Google" />
        <h3>Join our Executive Club</h3>
        <p className="airwaysPara">Enjoy booking quicker, paying with Avios, earning rewards <br/> and receiving special offers as an Executive Club Member.</p>
        <a className="contactUs" href="https://www.britishairways.com/travel/home/public/en_gb/" target="_blank" rel="noreferrer">Join us now   &gt;</a>
    </div>
  )
}

export default ImageWithText