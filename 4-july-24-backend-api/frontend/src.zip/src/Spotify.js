import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Row, Col } from 'react-bootstrap';

const Spotify = () => {

    const numArr = [4, 16, 9, 25]
    // const newArr = numArr.map(item => item * 2);
    // console.log(newArr)
    // const numbers1 = [{ "id": 4, "name": "new" }, { "id": 9, "name": "venka" }, { "id": 16, "name": "vel" }, { "id": 25, "name": "arun" }]
    // console.log(numArr.map(item => Math.sqrt(item) + 2))

    // const numbers = [{ "id": 4 }, { "id": 9 }, { "id": 16 }, { "id": 25 }]
    
    // const changedNum = numbers.map((obj) => {
    //      return { id:(obj.id) * 2 }
        
    // })
    //console.log(changedNum)
    //console.log(numArr.map(item => item > 5))

    const [data, setData] = useState([]);
    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:4000/musicLiked'); // Replace with your API endpoint
                console.log(response.data); // Output the entire response object

                // Assuming your API returns an object with an array inside
                setData(response.data); // Set the data state to the entire response object
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    const musicTitle = ["Popular artists", "Popular albums", "Popular songs", "New hitlist"]

    const popularArtists = [
        { image: require(`./assets/amazon/1._SS300_QL85_FMpng_.png`), name: "Pritam", subTitle: "Artist" },
        { image: require(`./assets/amazon/1._SS300_QL85_FMpng_2.png`), name: "Arijit Singh", subTitle: "Artist" },
        { image: require(`./assets/amazon/2._SS300_QL85_FMpng_.png`), name: "A.R. Rahman", subTitle: "Artist" },
        { image: require(`./assets/amazon/2._SS300_QL85_FMpng_2.png`), name: "Anirudh Ravichander", subTitle: "Artist" },
        { image: require(`./assets/amazon/02_Smartwatches_SBB_halo._SS300_QL85_FMpng_.png`), name: "Vishal Mishra", subTitle: "Artist" },
        { image: require(`./assets/amazon/3._SS300_QL85_FMpng_.png`), name: "Sachin-Jigar", subTitle: "Artist" }
    ]
    const popularAlbums = [
        { image: require(`./assets/amazon/3._SS300_QL85_FMpng_2.png`), name: "love hotel", subTitle: "leftovermax" },
        { image: require(`./assets/amazon/03_Smartwatches_SBB_halo._SS300_QL85_FMpng_.png`), name: "Ek Tha Raja", subTitle: "Badshah" },
        { image: require(`./assets/amazon/4._SS300_QL85_FMpng_.png`), name: "ANIMAL", subTitle: "Manan Bhardwaj, Vishal Mishra, Jaani" },
        { image: require(`./assets/amazon/4._SS300_QL85_FMpng_2.png`), name: "Moosetape", subTitle: "Sidhu Moose Wala" },
        { image: require(`./assets/amazon/05_Smartwatches_SBB_halo._SS300_QL85_FMpng_.png`), name: "Aashiqui 2", subTitle: "Mithoon, Ankit Tiwari, Jeet Gannguli" },
        { image: require(`./assets/amazon/04_Smartwatches_SBB_halo._SS300_QL85_FMpng_.png`), name: "Aavesham (Original...", subTitle: "Sushin Shyam, Vinayak Sasikumar" }
    ]
    const popularSongs = [
        { image: require(`./assets/amazon/1._SS300_QL85_FMpng_.png`), name: "Pritam", subTitle: "Artist" },
        { image: require(`./assets/amazon/1._SS300_QL85_FMpng_2.png`), name: "Arijit Singh", subTitle: "Artist" },
        { image: require(`./assets/amazon/2._SS300_QL85_FMpng_.png`), name: "A.R. Rahman", subTitle: "Artist" },
        { image: require(`./assets/amazon/2._SS300_QL85_FMpng_2.png`), name: "Anirudh Ravichander", subTitle: "Artist" },
        { image: require(`./assets/amazon/02_Smartwatches_SBB_halo._SS300_QL85_FMpng_.png`), name: "Vishal Mishra", subTitle: "Artist" },
        { image: require(`./assets/amazon/3._SS300_QL85_FMpng_.png`), name: "Sachin-Jigar", subTitle: "Artist" }
    ]
    const newHitlist = [
        { image: require(`./assets/amazon/3._SS300_QL85_FMpng_2.png`), name: "love hotel", subTitle: "leftovermax" },
        { image: require(`./assets/amazon/03_Smartwatches_SBB_halo._SS300_QL85_FMpng_.png`), name: "Ek Tha Raja", subTitle: "Badshah" },
        { image: require(`./assets/amazon/4._SS300_QL85_FMpng_.png`), name: "ANIMAL", subTitle: "Manan Bhardwaj, Vishal Mishra, Jaani" },
        { image: require(`./assets/amazon/4._SS300_QL85_FMpng_2.png`), name: "Moosetape", subTitle: "Sidhu Moose Wala" },
        { image: require(`./assets/amazon/05_Smartwatches_SBB_halo._SS300_QL85_FMpng_.png`), name: "Aashiqui 2", subTitle: "Mithoon, Ankit Tiwari, Jeet Gannguli" },
        { image: require(`./assets/amazon/04_Smartwatches_SBB_halo._SS300_QL85_FMpng_.png`), name: "Aavesham (Original...", subTitle: "Sushin Shyam, Vinayak Sasikumar" }
    ]

    const getTitleData = (title) => {

        switch (title) {
            case 'Popular artists': return popularArtists
            case 'Popular albums': return popularAlbums
            case 'Popular songs': return popularSongs
            case 'New hitlist': return newHitlist
            default: return '';
        }

    }

    return (
        <header className="mb-10">
            <section>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 vh-100 bg-danger">
                            <ul>
                                <li>ashbdhsab</li>
                                <li>ashbdhsab</li>
                                <li>ashbdhsab</li>
                            </ul>
                        </div>
                        <div className="col-lg-9 bg-primary bg-primary">
                            <div className="listpage" key="90" style={{ paddingLeft: "20px" }}>
                                {/* <p>{numbers.map(obj => {
                                        return {
                                            id: Math.sqrt(obj.id)
                                        };
                                    })
                                    }
                                    </p> */}
                                <h3>Music Liked</h3>
                                <Row>
                                    {data.map((items, idx) => (
                                        <Col key={idx} className="fixedSize" style={{ display: "block" }}>
                                            <img className="spotifyDimension" src={items.image} alt="Google" />
                                            <p>{items.title}<br /><span style={{ 'fontSize': '10px', "color": "#fcfbfb" }}>{items.title}</span></p>
                                            <audio controls className="spotifyDimension">
                                                <source src={items.audio} type="audio/mpeg" />
                                            </audio>
                                        </Col>
                                    ))}
                                </Row>
                            </div>

                            {musicTitle.map((items, index) => (
                                <div className="listpage" key={index} style={{ paddingLeft: "20px" }}>
                                    <h3>{items}</h3>
                                    <Row>
                                        {getTitleData(items).map((key, idx) => (
                                            <Col key={idx} className="fixedSize" style={{ display: "block" }}>
                                                <img className="spotifyDimension" src={key.image} alt="Google" />
                                                <p>{key.name}<br /><span style={{ 'fontSize': '10px', "color": "#fcfbfb" }}>{key.subTitle}</span></p>
                                            </Col>
                                        ))}
                                    </Row>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>
        </header>
    )
}

export default Spotify