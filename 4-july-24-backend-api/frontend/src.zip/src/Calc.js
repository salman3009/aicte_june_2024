import React,{ useState } from 'react'

const Calc = () => {

    let fieldVal =''

    const [val,setVal] = useState(0)
    const [resVal,setResVal] = useState(0)
    const [num,setNum] = useState(0)
    const [exp,setExp] = useState(0)
    const [num1,setNum1] = useState(0)

    function dis(a){
        if(val===0) fieldVal = a; 
        else fieldVal = val + a; 
        
        setVal(fieldVal)

        if(num===0) { setNum(a); }
        else if(exp===0) { setExp(a);}
        else if(num1===0) { setNum1(a);}
    }

    function solve(){
        console.log({num,exp,num1})
        
        let y =''

        switch(exp){
            case '+': y = +num + +num1;  break;
            case '-': y = num - num1;    break
            case '*': y = +num * +num1;  break
            case '/': y = +num / +num1;  break
            default: y=0
        }
        setResVal(y)
    }

    function clr() { 
        setNum(0)
        setExp(0)
        setNum1(0)
        setVal(0)
        setResVal(0)
    }

    function myFunction(event) { 
        if (event.key === '0' || event.key === '1' 
            || event.key === '2' || event.key === '3' 
            || event.key === '4' || event.key === '5' 
            || event.key === '6' || event.key === '7' 
            || event.key === '8' || event.key === '9' 
            || event.key === '+' || event.key === '-' 
            || event.key === '*' || event.key === '/') 
            console.log('dad')
    } 

  return (<div>
    <table id="calcu"> 
    <tbody>
    <tr> 
            <td colSpan="2"><input type="text" id="result" value={val} readOnly/></td> 
            <td colSpan="1"><input type="text" id="result1"  value={resVal} readOnly/></td> 
            <td><input type="button" value="c" onClick={() => clr()} /> </td> 
        </tr> 
        <tr> 
            <td><input type="button" value="1" onClick={() => dis('1')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="2" onClick={() => dis('2')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="3" onClick={() => dis('3')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="/" onClick={() => dis('/')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
        </tr>

        <tr> 
            <td><input type="button" value="4" onClick={()=>dis('4')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="5" onClick={()=>dis('5')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="6" onClick={()=>dis('6')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="*" onClick={()=>dis('*')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
        </tr> 
        <tr> 
            <td><input type="button" value="7" onClick={()=>dis('7')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="8" onClick={()=>dis('8')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="9" onClick={()=>dis('9')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="-" onClick={()=>dis('-')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
        </tr> 
        <tr> 
            <td><input type="button" value="0" onClick={()=>dis('0')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            <td><input type="button" value="." onClick={()=>dis('.')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
            
            <td><input type="button" value="=" onClick={()=>solve()} /> </td>
  
            <td><input type="button" value="+" onClick={()=>dis('+')}
                        onKeyDown={(event) => myFunction(event)} /> </td> 
        </tr> 
        </tbody>
    </table> 
    </div>
  )
}

export default Calc