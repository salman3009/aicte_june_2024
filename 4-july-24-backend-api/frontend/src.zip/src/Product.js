import {FaRupeeSign} from 'react-icons/fa'
import './Product.css';

const Product = () => {

    const productData = [
            {
                image:require(`./assets/Wearables._CB574550011_.png`),
                topic:"Noise Buds N1",
                list1:"40 hrs &gt; of Playtime",
                list2:"40 ms Ultra Low Latency",
                price:"3,499",
                discountPrice:"1,099"
            },
            {
                    image:require(`./assets/Tablets._CB574550011_.png`),
                    topic:"Noise Plus 3 Max",
                    list1:"2.0 Display",
                    list2:"Functional Crown",
                    price:"6,999",
                    discountPrice:"1,399"
            },
            {
                    image:require(`./assets/SECURITY-CAMERA._CB574546476_.png`),
                    topic:"Logitech G300s",
                    list1:"9 Programmable Controls",
                    list2:"2500 DPI",
                    price:"2,295",
                    discountPrice:"999"
            },
            {
                    image:require(`./assets/HF_PHASE_978X900._SS900_QL85_.jpg`),
                    topic:"Tygot Ring light tripod",
                    list1:"USB-Powered",
                    list2:"Color Adjustment",
                    price:"1,999",
                    discountPrice:"799"
            },
            {
                    image:require(`./assets/Headphones._CB574550011_.png`),
                    topic:"boAt Airdopes 91",
                    list1:"45 hrs Playtime",
                    list2:"50 ms Low Latency",
                    price:"4,900",
                    discountPrice:"799"
            },
            {
                    image:require(`./assets/moonwatch-978x900_SL._SS900_QL85_.jpg`),
                    topic:"Visionary Ultra",
                    list1:"fStainless steel Luxury",
                    list2:"1.98 AMOLED",
                    price:"2900" ,
                    iscountPrice:"2400"
            },
            {
                    image:require(`./assets/HEADPHONE._CB574546476_.png`),
                    topic:"CP plus Ezylite 3MP",
                    list1:"Al-based human detection",
                    list2:"Night vision",
                    price:"2,300",
                    discountPrice:"1,299"
            },
            {
                    image:require(`./assets/Maono_MIC_Spotlight._SS900_QL85_.jpg`),
                    topic:"VW Car Dash Camera",
                    list1:"FHD footage",
                    list2:"low light performance",
                    price:"6,999",
                    discountPrice:"1,799" 
            }
    ]

    return (
        <div className="container">
            {productData.map(
                item => (
                <div key={item.key}>
                <img className="ImgDimension" src ={item.image} alt="Google" />
                <h3 className='topic'>{item.topic}</h3>
                <ul>
                    <li>{item.list1}</li>
                    <li>{item.list2}</li>
                </ul>
                <button>
                    <span className="marginLeft"><del><sup><FaRupeeSign /></sup>{item.price}</del></span>
                    <span className="marginLeft"><sup><FaRupeeSign /></sup>{item.discountPrice}</span>
                </button>
                </div>
            )) }
        </div>
    )
}

export default Product