// import Amazon from './Amazon';
// import ImageWithText from './ImageWithText';
// import Product from './Product';
//import './Product.css';
// import Calc from './Calc';
// import './Calc.css';
//import Textcolor from './Textcolor';
//import Form from './Form';
import Spotify from './Spotify';
import './Spotify.css';
import Header from './Header';
import Login from './Login';
import Register from './Register';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

const App = () => {
    
    return (
        <div>
            <BrowserRouter>
            <Header />
                <Routes>
                    <Route path="/" element={<Spotify />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                </Routes>
            </BrowserRouter>
            {/* <ImageWithText />
                    <Product />
                    <Spotify />
                    <Calc />
                    <Textcolor />
                    <Form />
                */}
        </div>
    )
}

export default App;