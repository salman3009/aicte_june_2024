import React,{useState} from 'react';
import colorNames from 'colornames'

const Textcolor = () => {
    const [colorTxt,setColorTxt] = useState('white')
    const [txtColor,setTxtColor] = useState('black')

    const bgColor = colorTxt

    return (
        <div>
            <form>
                <div className='row' style={{ paddingTop: "50px" }}>
                    <div className='col-md-4'>

                    </div>
                    <div className='col-md-4'>
                        <p>{colorNames(colorTxt)}</p>
                        <div className="mb-3 form-check">
                            <input className="form-control" value={colorTxt} id="bg" name="bg" type="text" style={{ "background": bgColor, color: txtColor, paddingLeft: "1.5em", border: "1px solid black", height: "100px", textAlign: "center" }} />
                        </div>
                        <div className="mb-3 form-check">
                            <input type="text" className="form-control" id="color" name="color" value={colorTxt} onChange={(e) => {setColorTxt(e.target.value)}} />
                        </div>
                        <div className="mb-3 form-check">
                            <input type="button" className="form-control" id="toggle" name="toggle" value="Toggle the Box Color" onClick={() => {setTxtColor((txtColor==="black") ? "white" : "black")}} />
                        </div>
                    </div>
                </div>


            </form>
        </div>
    )
}

export default Textcolor